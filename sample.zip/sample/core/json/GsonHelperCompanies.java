package sample.core.json;

import java.util.List;

public class GsonHelperCompanies {
    private int recordID;
    private String recordName;
    private List<RecordsCompanies> records;

    public void setRecords(List<RecordsCompanies> records) {
        this.records = records;
    }

    public void setRecordName(String recordName) {
        this.recordName = recordName;
    }

    public void setRecordID(int recordID) {
        this.recordID = recordID;
    }
}
