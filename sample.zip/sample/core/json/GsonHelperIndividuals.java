package sample.core.json;

import java.util.List;

public class GsonHelperIndividuals {

    private int recordID;
    private String recordName;
    private List<RecordsIndividuals> records;

    public void setRecords(List<RecordsIndividuals> records) {
        this.records = records;
    }

    public void setRecordName(String recordName) {
        this.recordName = recordName;
    }

    public void setRecordID(int recordID) {
        this.recordID = recordID;
    }

}