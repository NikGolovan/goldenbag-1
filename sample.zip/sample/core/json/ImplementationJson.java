package sample.core.json;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import sample.core.handlers.ErrorAndExceptionHandler;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ImplementationJson {
    private static final String CONNECTION_URL_IND = "jdbc:sqlite:clients_individuals.db";
    private static final String CONNECTION_URL_COMP = "jdbc:sqlite:clients_companies.db";
    private static final String FILE_ENCODING = "UTF-8";

    public void importJson(File file, int tabIndex) {
        if (tabIndex == 0) {
            importToIndividuals(file);
        } else {
            importToCompanies(file);
        }
    }

    public void importToIndividuals(File file) {

        try (Connection connection = DriverManager.getConnection(CONNECTION_URL_IND);
             PreparedStatement preparedStatement = connection.prepareStatement("insert into content_individuals values (?, ?, ?, ?, ?)")) {

            JsonParser jsonParser = new JsonParser();
            Object object = jsonParser.parse(new FileReader(file));
            JsonObject jsonObject = (JsonObject) object;

            JsonArray test = (JsonArray) jsonObject.get("records");
            List<Integer> test2 = verifyId(test);

            for (int i = 0; i < test.size(); i++) {
                Integer id = Integer.valueOf(String.valueOf(test.get(i).getAsJsonObject().get("id")));
                String firstName = test.get(i).getAsJsonObject().get("firstName").getAsString();
                String lastName = test.get(i).getAsJsonObject().get("lastName").getAsString();
                String emailAdress = test.get(i).getAsJsonObject().get("emailAdress").getAsString();
                String dateLicenseValid = test.get(i).getAsJsonObject().get("dateLicenseValid").getAsString();

                preparedStatement.setInt(1, id);
                preparedStatement.setString(2, firstName);
                preparedStatement.setString(3, lastName);
                preparedStatement.setString(4, emailAdress);
                preparedStatement.setString(5, dateLicenseValid);

                preparedStatement.executeUpdate();
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not open a JSON  file...", e.getMessage());
            e.printStackTrace();
        }
    }

    public void importToCompanies(File file) {

        try (Connection connection = DriverManager.getConnection(CONNECTION_URL_COMP);
             PreparedStatement preparedStatement = connection.prepareStatement("insert into content_companies values (?, ?, ?, ?)")) {

            JsonParser jsonParser = new JsonParser();
            Object object = jsonParser.parse(new FileReader(file));
            JsonObject jsonObject = (JsonObject) object;

            JsonArray test = (JsonArray) jsonObject.get("records");
            List<Integer> test2 = verifyId(test);

            for (int i = 0; i < test.size(); i++) {
                Integer id = Integer.valueOf(String.valueOf(test.get(i).getAsJsonObject().get("id")));
                String companyName = test.get(i).getAsJsonObject().get("companyName").getAsString();
                String emailAdress = test.get(i).getAsJsonObject().get("emailAdress").getAsString();
                String dateLicenseValid = test.get(i).getAsJsonObject().get("dateLicenseValid").getAsString();

                preparedStatement.setInt(1, id);
                preparedStatement.setString(2, companyName);
                preparedStatement.setString(3, emailAdress);
                preparedStatement.setString(4, dateLicenseValid);

                preparedStatement.executeUpdate();
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not open a JSON  file...", e.getMessage());
            e.printStackTrace();
        }
    }

    // TODO: make smart import
    public List<Integer> verifyId(JsonArray test) {
        List<Integer> allDbId = new ArrayList<>();
        List<Integer> allJsonId = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(CONNECTION_URL_IND);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("Select id from content_individuals")){

            while (resultSet.next()) {
                allDbId.add(resultSet.getInt(1));
            }

            for (int i = 0; i < test.size(); i++) {
                allJsonId.add(Integer.valueOf(String.valueOf(test.get(i).getAsJsonObject().get("id"))));
            }

            for (int i = 0; i < allJsonId.size(); i++) {
                for (int j = 0; j < allDbId.size(); j++) {
                    if (allJsonId.get(i) == allDbId.get(j))
                        allJsonId.remove(i);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return(allJsonId);
    }

    public void getRecordsIndividuals(ResultSet resultSet, List<RecordsIndividuals> items) {
        try {
            while (resultSet.next()) {
                RecordsIndividuals record = new RecordsIndividuals();

                record.setId(resultSet.getInt(1));
                record.setFirstName(resultSet.getString(2));
                record.setLastName(resultSet.getString(3));
                record.setEmailAdress(resultSet.getString(4));
                record.setDateLicenseValid(resultSet.getString(5));
                items.add(record);
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not read data from the table...", e.getMessage());
        } finally {
            try {
                resultSet.close();
            } catch (SQLException e) {
                new ErrorAndExceptionHandler().showErrorAlert("Failed to close resultSet after reading the data...", e.getMessage());
            }
        }
    }

    public void getRecordsCompanies(ResultSet resultSet, List<RecordsCompanies> items) {
        try {
            while (resultSet.next()) {
                RecordsCompanies record = new RecordsCompanies();

                record.setId(resultSet.getInt(1));
                record.setCompanyName(resultSet.getString(2));
                record.setEmailAdress(resultSet.getString(3));
                record.setDateLicenseValid(resultSet.getString(4));
                items.add(record);
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not read data from the table...", e.getMessage());
        } finally {
            try {
                resultSet.close();
            } catch (SQLException e) {
                new ErrorAndExceptionHandler().showErrorAlert("Failed to close resultSet after reading the data...", e.getMessage());
            }
        }
    }

    public void exportIndividuals(File file, List<Integer> items) {
        GsonHelperIndividuals metadata = new GsonHelperIndividuals();
        Gson gson = new Gson();
        List<RecordsIndividuals> list = new ArrayList<>();

        metadata.setRecordID(1);
        metadata.setRecordName("JSON DATA FROM TABLE INDIVIDUALS");

        if (items.size() <= 1) {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL_IND);
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("Select * from content_individuals")) {

                getRecordsIndividuals(resultSet, list);

                metadata.setRecords(list);
                String json = gson.toJson(metadata);
                createJsonFile(json, file);

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not export data to JSON file...", e.getMessage());
            }
        } else {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL_IND);
                 Statement statement = connection.createStatement()) {

                for (int i = 0; i < items.size(); i++) {
                    ResultSet resultSet = statement.executeQuery("Select * from content_individuals where id = " + items.get(i));
                    getRecordsIndividuals(resultSet, list);
                }

                metadata.setRecords(list);
                String json = gson.toJson(metadata);
                createJsonFile(json, file);

            } catch(Exception e){
                new ErrorAndExceptionHandler().showErrorAlert("Could not export data to JSON file...", e.getMessage());
            }
        }
    }

    public void exportCompanies(File file, List<Integer> items) {
        GsonHelperCompanies metadata = new GsonHelperCompanies();
        Gson gson = new Gson();
        List<RecordsCompanies> list = new ArrayList<>();

        metadata.setRecordID(1);
        metadata.setRecordName("JSON DATA FROM TABLE COMPANIES");

        if (items.size() <= 1) {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL_COMP);
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("Select * from content_companies")) {

                getRecordsCompanies(resultSet, list);

                metadata.setRecords(list);
                String json = gson.toJson(metadata);
                createJsonFile(json, file);

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not export data to JSON file...", e.getMessage());
            }
        } else {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL_COMP);
                 Statement statement = connection.createStatement()) {

                for (int i = 0; i < items.size(); i++) {
                    ResultSet resultSet = statement.executeQuery("Select * from content_companies where id = " + items.get(i));
                    getRecordsCompanies(resultSet, list);
                }

                metadata.setRecords(list);
                String json = gson.toJson(metadata);
                createJsonFile(json, file);

            } catch(Exception e){
                new ErrorAndExceptionHandler().showErrorAlert("Could not export data to JSON file...", e.getMessage());
            }
        }
    }

    public void exportToJson(File file, List<Integer> items, int tabIndex) {
        if (tabIndex == 0)
            exportIndividuals(file, items);
        else
            exportCompanies(file, items);
    }


    public void createJsonFile(String json, File file) {
        try {
            file.createNewFile();
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not create a JSON file...", e.getMessage());
        }

        try (FileOutputStream fileOutputStream = new FileOutputStream(file, true);
             OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream, FILE_ENCODING);
             BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
             PrintWriter printWriter = new PrintWriter(bufferedWriter, true)) {

            printWriter.write(json);

        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not write data to created JSON file...", e.getMessage());
        }
         new ErrorAndExceptionHandler().showConfirmationAlert("JSON file has been successfully created.");
    }
}
