package sample.core.comp;

import com.jfoenix.controls.JFXTextField;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;
import sample.core.handlers.ErrorAndExceptionHandler;

import java.io.FileInputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class NewCompanyController implements Initializable {
    @FXML private JFXTextField txtCompanyName;
    @FXML private JFXTextField txtEmailAddress;
    @FXML private DatePicker datePickerNewCompany;

    private static final String CONNECTION_URL = "jdbc:sqlite:clients_companies.db";
    private static final String FILE_NAME = "configuration.properties";

    public void setCurrentDate() {
        try {
            datePickerNewCompany.setValue(LocalDate.now());
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Oops, an error has occurred. Details:\n" + e.getMessage(), ButtonType.OK);
        }
    }

    public void discard() {
        Stage stage = (Stage) datePickerNewCompany.getScene().getWindow();
        stage.close();
    }

    public boolean fieldsAreEmpty(List<String> fields) {
        for (int i = 0; i < fields.size(); i++) {
            if (fields.get(i).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    private String getDateFromProperties() {
        Properties properties = new Properties();
        String datePreferenceString = null;

        try (FileInputStream fileInputStream = new FileInputStream(FILE_NAME)) {
            properties.load(fileInputStream);

            datePreferenceString = properties.getProperty("datePreferenceString");

        } catch (Exception e) {
            e.printStackTrace();
            new ErrorAndExceptionHandler().showErrorAlert("Could not apply properties on load...", e.toString());
        }
        return datePreferenceString;
    }

    public void saveInformation() {
        String companyName = txtCompanyName.getText();
        String emailAddress = txtEmailAddress.getText();
        String dateLicenseValid = datePickerNewCompany.getValue().format(DateTimeFormatter.ofPattern(getDateFromProperties()));

        List<String> fields = new ArrayList<>();

        fields.add(emailAddress);
        fields.add(dateLicenseValid);

        if (fieldsAreEmpty(fields)) {
            new ErrorAndExceptionHandler().showWarningAlert("Form is incomplete.");
            return;
        }

        uploadToSqlite(companyName, emailAddress, dateLicenseValid);

        txtCompanyName.setText("");
        txtEmailAddress.setText("");
    }

    public void uploadToSqlite(String companyName, String emailAddress, String datePayment) {
        Platform.runLater(() -> {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL);
                 PreparedStatement preparedStatement = connection.prepareStatement("insert into content_companies values (?, ?, ?, ?)")) {

                preparedStatement.setString(2, companyName);
                preparedStatement.setString(3, emailAddress);
                preparedStatement.setString(4, datePayment);

                preparedStatement.executeUpdate();

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not upload information to the table...", e.toString());
            }
        });
        new Alert(Alert.AlertType.INFORMATION, "New company has been successfully added to the database.", ButtonType.OK).showAndWait();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setCurrentDate();
    }
}
