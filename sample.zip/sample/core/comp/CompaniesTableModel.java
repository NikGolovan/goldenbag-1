package sample.core.comp;

public class CompaniesTableModel {
    Integer id;
    String  companyName, emailAddress, LicenseValidFrom;

    public CompaniesTableModel(Integer id, String companyName, String emailAddress, String LicenseValidFrom) {
        this.id = id;
        this.companyName = companyName;
        this.emailAddress = emailAddress;
        this.LicenseValidFrom = LicenseValidFrom;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getDateLicenseValid() {
        return LicenseValidFrom;
    }

    public void setDateLicenseValid(String LicenseValidFrom) {
        this.LicenseValidFrom = LicenseValidFrom;
    }
}
