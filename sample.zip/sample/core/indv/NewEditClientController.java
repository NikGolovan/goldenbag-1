package sample.core.indv;

import com.jfoenix.controls.JFXDatePicker;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import sample.core.handlers.ErrorAndExceptionHandler;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class NewEditClientController implements Initializable {

    @FXML public TextField txtId;
    @FXML public TextField txtFirstname;
    @FXML public TextField txtLastname;
    @FXML public TextField txtCompanyName;
    @FXML public TextField txtEmailAddress;
    @FXML public DatePicker dateField;
    @FXML public Button btnDiscard;
    @FXML public Button btnConfirm;

    public int tabIndex = 0;
    private static final String CONNECTION_URL_IND = "jdbc:sqlite:clients_individuals.db";
    private static final String CONNECTION_URL_COMP = "jdbc:sqlite:clients_companies.db";

    public void setFields(int id, String firstName, String lastName, String companyName, String emailAddress, String datePayment, int tabIndex) {
        this.txtId.setText(String.valueOf(id));
        this.txtFirstname.setText(firstName);
        this.txtLastname.setText(lastName);
        this.txtCompanyName.setText(companyName);
        this.txtEmailAddress.setText(emailAddress);
        this.dateField.setValue(LocalDate.parse(datePayment));
        this.tabIndex = tabIndex;
    }

    public void discard() {
        Stage stage = (Stage) btnDiscard.getScene().getWindow();
        stage.close();
    }

    public void saveChanges() {
        if (tabIndex != 0) {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL_COMP);
                 PreparedStatement preparedStatement = connection.prepareStatement("update content_companies set companyName = ?," +
                         " emailAddress = ?, LicenseValidFrom = ? where id = " + txtId.getText())) {

                preparedStatement.setString(1, txtCompanyName.getText().toString());
                preparedStatement.setString(2, txtEmailAddress.getText().toString());
                preparedStatement.setString(3, dateField.getValue().toString());

                preparedStatement.executeUpdate();

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not save information...", e.getMessage());
            }
            new Alert(Alert.AlertType.INFORMATION, "The information was successfully updated.", ButtonType.OK).showAndWait();
        } else {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL_IND);
                 PreparedStatement preparedStatement = connection.prepareStatement("update content_individuals set firstName = ?," +
                         " lastName = ?, emailAdress = ?, LicenseValidFrom = ? where id = " + txtId.getText())) {

                preparedStatement.setString(1, txtFirstname.getText().toString());
                preparedStatement.setString(2, txtLastname.getText().toString());
                preparedStatement.setString(3, txtEmailAddress.getText().toString());
                preparedStatement.setString(4, dateField.getValue().toString());

                preparedStatement.executeUpdate();

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not save information...", e.getMessage());
            }
            new Alert(Alert.AlertType.INFORMATION, "The information was successfully updated.", ButtonType.OK).showAndWait();
        }
    }

    public void setCurrentDate() {
        try {
            dateField.setValue(LocalDate.now());
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Oops, an error has occurred. Details:\n" + e.getMessage(), ButtonType.OK);
        }
    }

    @Override
    public void initialize (URL location, ResourceBundle resources){

    }
}
