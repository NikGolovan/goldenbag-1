package sample.core.indv;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import sample.core.handlers.ErrorAndExceptionHandler;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class EditClientController implements Initializable {

    @FXML public TextField txtId;
    @FXML public TextField txtFirstName;
    @FXML public TextField txtLastName;
    @FXML public TextField txtEmailAdress;
    @FXML public DatePicker datePayment;
    @FXML public Button btnCancel;
    @FXML public Label lblUpdated;

    private static final String CONNECTION_URL = "jdbc:sqlite:clients_individuals.db";

    public void setFields(int id, String firstName, String lastName, String emailAdress, String datePayment) {
        this.txtId.setText(String.valueOf(id));
        this.txtFirstName.setText(firstName);
        this.txtLastName.setText(lastName);
        this.txtEmailAdress.setText(emailAdress);
        this.datePayment.setValue(LocalDate.parse(datePayment));
    }

    public void cancel() {
        Stage stage = (Stage) btnCancel.getScene().getWindow();
        stage.close();
    }

    public void save() {
        try (Connection connection = DriverManager.getConnection(CONNECTION_URL);
             PreparedStatement preparedStatement = connection.prepareStatement("update content_individuals set firstName = ?," +
                     " lastName = ?, emailAdress = ?, LicenseValidFrom = ? where id = " + txtId.getText())) {

            preparedStatement.setString(1, txtFirstName.getText().toString());
            preparedStatement.setString(2, txtLastName.getText().toString());
            preparedStatement.setString(3, txtEmailAdress.getText().toString());
            preparedStatement.setString(4, datePayment.getValue().toString());

            preparedStatement.executeUpdate();

        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not save information...", e.getMessage());
        }
        lblUpdated.setVisible(true);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        lblUpdated.setVisible(false);
    }
}
