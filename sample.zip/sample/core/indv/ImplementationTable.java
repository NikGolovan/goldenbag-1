package sample.core.indv;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import sample.core.comp.CompaniesTableModel;
import sample.core.comp.ImplementationTableCompany;
import sample.core.handlers.ErrorAndExceptionHandler;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ImplementationTable {
    private static final String CONNECTION_URL = "jdbc:sqlite:clients_individuals.db";

    private ObservableList<ModelTable> oblist = FXCollections.observableArrayList();

    public void createTable() {
        try (Connection connection = DriverManager.getConnection(CONNECTION_URL);
             Statement statement = connection.createStatement()) {
            statement.execute("create table if not exists content_individuals (id INTEGER PRIMARY KEY, FirstName VARCHAR(60), " +
                    "LastName VARCHAR(60), EmailAdress VARCHAR(80), LicenseValidFrom VARCHAR(60))");
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not create table for database...", e.toString());
        }
    }

    public boolean fieldsAreEmpty(List<String> fields) {
        for (int i = 0; i < fields.size(); i++) {
            if (fields.get(i).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    public void uploadToSqlite(String firstName, String lastName, String emailAdress, String datePayment) {
        Platform.runLater(() -> {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL);
                 PreparedStatement preparedStatement = connection.prepareStatement("insert into content_individuals values (?, ?, ?, ?, ?)")) {

                preparedStatement.setString(2, firstName);
                preparedStatement.setString(3, lastName);
                preparedStatement.setString(4, emailAdress);
                preparedStatement.setString(5, datePayment);

                preparedStatement.executeUpdate();

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not upload information to the table...", e.toString());
            }
        });
    }

    public void saveInformation(String firstName, String lastName, String emailAdress, String datePayment) {
        List<String> fields = new ArrayList<>();

        fields.add(firstName);
        fields.add(lastName);
        fields.add(String.valueOf(datePayment));
        fields.add(emailAdress);

        if (fieldsAreEmpty(fields)) {
            new ErrorAndExceptionHandler().showWarningAlert("Form is incomplete.");
            return;
        }
        uploadToSqlite(firstName, lastName, emailAdress, datePayment);
    }

    public void deleteClient(List<Integer> items, String tableName, String connectionUrl) {
        try (Connection connection = DriverManager.getConnection(connectionUrl);
             Statement statement = connection.createStatement()) {

            for (int i = 0; i < items.size(); i++) {
                statement.execute("delete from " + tableName + " where id like '%" + items.get(i) + "%'");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void editClient(TableView<ModelTable> tableInd, TableView<CompaniesTableModel> tableComp, int tabIndex) {
        if (tabIndex == 0) {
            int id = tableInd.getSelectionModel().getSelectedItem().getId();
            String firstName = tableInd.getSelectionModel().getSelectedItem().getFirstName();
            String lastName = tableInd.getSelectionModel().getSelectedItem().getLastName();
            String emailAddress = tableInd.getSelectionModel().getSelectedItem().getEmailAdress();
            String datePayment = tableInd.getSelectionModel().getSelectedItem().getDateLicenseValid();
            openAsEditClient(id, firstName, lastName, emailAddress, datePayment, tabIndex);
        } else {
            int id = tableComp.getSelectionModel().getSelectedItem().getId();
            String companyName = tableComp.getSelectionModel().getSelectedItem().getCompanyName();
            String emailAddress = tableComp.getSelectionModel().getSelectedItem().getEmailAddress();
            String datePayment = tableComp.getSelectionModel().getSelectedItem().getDateLicenseValid();
            openAsEditCompany(id, companyName, emailAddress, datePayment, tabIndex);
        }
    }

    public void openAsEditClient(int id, String firstName, String lastName, String emailAddress, String datePayment, int tabIndex) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/sample/gui/newEditInformation10.fxml"));
            fxmlLoader.load();

            NewEditClientController editClientController = fxmlLoader.getController();
            editClientController.setFields(id, firstName, lastName, "N/A", emailAddress, datePayment, tabIndex);

            Parent parent = fxmlLoader.getRoot();
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Edit Information");
            stage.setScene(new Scene(parent));
            stage.setResizable(false);

            stage.show();

        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not edit information...", e.toString());
            e.printStackTrace();
        }
    }

    public void openAsEditCompany(int id,String companyName, String emailAddress, String datePayment, int tabIndex) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/sample/gui/newEditInformation10.fxml"));
            fxmlLoader.load();

            NewEditClientController editClientController = fxmlLoader.getController();
            editClientController.setFields(id, "N/A", "N/A", companyName, emailAddress, datePayment, tabIndex);

            Parent parent = fxmlLoader.getRoot();
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Edit Information");
            stage.setScene(new Scene(parent));
            stage.setResizable(false);

            stage.show();

        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not edit information...", e.toString());
        }
    }
}
