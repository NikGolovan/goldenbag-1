package sample;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import sample.core.comp.CompaniesTableModel;
import sample.core.comp.ImplementationTableCompany;
import sample.core.csv.ImplementationCsv;
import sample.core.indv.ImplementationTable;
import sample.core.indv.ModelTable;
import sample.core.json.ImplementationJson;
import sample.core.handlers.ErrorAndExceptionHandler;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.*;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.List;

public class Controller implements Initializable {
    @FXML
    private CheckBox checkIndividual;
    @FXML
    private CheckBox checkCompany;
    @FXML
    private TextField txtCompanyName;
    @FXML
    private TextField txtFirstName;
    @FXML
    private TextField txtLastName;
    @FXML
    public DatePicker datePayment;
    @FXML
    private TextField txtEmailAdress;
    @FXML
    private TextField txtSearchClient;
    @FXML
    private Label lblRefreshed;
    @FXML
    private Label lblRefreshedTime;
    @FXML
    private MenuItem mnEditCell;
    @FXML
    private MenuItem mnDeleteCell;
    @FXML
    private MenuItem mnTabEdit;
    @FXML
    private MenuItem mnTabCopy;
    @FXML
    private SeparatorMenuItem sepMenuExport;
    @FXML
    private MenuItem mnTabExportToJson;
    @FXML
    private MenuItem mnTabExportToCsv;
    @FXML
    private MenuItem mnTabDelete;
    @FXML
    private MenuItem subMenuExportCsv;
    @FXML
    private MenuItem subMenuExportJson;

    @FXML
    private TableColumn<CompaniesTableModel, Integer> idCompany;
    @FXML
    private TableView<CompaniesTableModel> tableCompanies;
    @FXML
    private TableColumn<CompaniesTableModel, String> companyName;
    @FXML
    private TableColumn<CompaniesTableModel, String> emailAddressCompany;
    @FXML
    private TableColumn<CompaniesTableModel, String> dateLicenseValidCompany;

    @FXML
    private TableView<ModelTable> tableIndividuals;
    @FXML
    private TableColumn<ModelTable, Integer> id;
    @FXML
    private TableColumn<ModelTable, String> firstName;
    @FXML
    private TableColumn<ModelTable, String> lastName;
    @FXML
    private TableColumn<ModelTable, String> emailAdress;
    @FXML
    private TableColumn<ModelTable, String> dateLicenseValid;

    private static final String BACKGROUND_COLOR_LOCKED = "-fx-control-inner-background: #F7F7F7";
    private static final String BACKGROUND_COLOR_UNLOCKED = "-fx-control-inner-background: #FFFFFF";

    public void launchImportJson() {
        try {
            FileChooser fileChooser = new FileChooser();
            FileChooser.ExtensionFilter extensionFilter = new FileChooser.ExtensionFilter("Files *.json", "*.json");
            File file = fileChooser.showOpenDialog(new Stage());

            fileChooser.getExtensionFilters().add(extensionFilter);

            if (file == null) {
                return;
            } else {
                //new ImplementationJson().importJson(file);
                //new ImplementationTable().refreshData(tableIndividuals); TODO: uncomment afterwards
                //new ImplementationTable().populateData(tableIndividuals, id, firstName, lastName, emailAdress, dateLicenseValid);
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Failed to choose a file...", e.getMessage());
        }
    }

    public void searchClient() {
        //new ImplementationTable().searchClient(tableIndividuals, txtSearchClient.getText().toString());
    }

    public void launchExportToJson() {
        List<Integer> items = new ArrayList<>();

        try {
            FileChooser fileChooser = new FileChooser();
            File file = fileChooser.showSaveDialog(new Stage());

            items = getSelectedRows();

            if (file == null) {
                return;
            } else {
                file = new File(file.getAbsolutePath() + ".json");
                //new ImplementationJson().exportToJson(file, items);
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not process the task...", e.getMessage());
        }
    }

    public List<Integer> getSelectedRows() {
        List<Integer> items = new ArrayList<>();
        for (int i = 0; i < tableIndividuals.getSelectionModel().getSelectedItems().size(); i++) {
            items.add(tableIndividuals.getSelectionModel().getSelectedItems().get(i).getId());
        }
        return (items);
    }

    public void print() {
        //TODO: implement print method
    }

    public void setCurrentDate() {
        try {
            datePayment.setValue(LocalDate.now());
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Oops, an error has occurred. Details:\n" + e.getMessage(), ButtonType.OK);
        }
    }

    public void selectIdividualLicense() {
        checkCompany.setSelected(false);
        txtCompanyName.setEditable(false);
        txtCompanyName.setStyle(BACKGROUND_COLOR_LOCKED);
        txtFirstName.setStyle(BACKGROUND_COLOR_UNLOCKED);
        txtFirstName.setEditable(true);
        txtLastName.setStyle(BACKGROUND_COLOR_UNLOCKED);
        txtLastName.setEditable(true);
    }

    public void selectCompanyLicense() {
        checkIndividual.setSelected(false);
        txtCompanyName.setEditable(true);
        txtCompanyName.setStyle(BACKGROUND_COLOR_UNLOCKED);
        txtFirstName.setStyle(BACKGROUND_COLOR_LOCKED);
        txtFirstName.setEditable(false);
        txtLastName.setStyle(BACKGROUND_COLOR_LOCKED);
        txtLastName.setEditable(false);
    }

    public void launchSaveInformation() {
        boolean errorOccured= false;
        String companyNameString = txtCompanyName.getText();
        String firstNameString = txtFirstName.getText();
        String lastNameString = txtLastName.getText();
        String dateString = datePayment.getValue().toString();
        String emailAddressSting = txtEmailAdress.getText();

        if (checkIndividual.isSelected()) {
            new ImplementationTable().saveInformation(firstNameString, lastNameString, emailAddressSting, dateString);
           // new ImplementationTable().refreshData(tableIndividuals);
            //new ImplementationTable().populateData(tableIndividuals, id, firstName, lastName, emailAdress, dateLicenseValid);
        } else if (checkCompany.isSelected()) {
            new ImplementationTableCompany().saveInformation(companyNameString, emailAddressSting, dateString);
            new ImplementationTableCompany().refreshData(tableCompanies);
            new ImplementationTableCompany().populateData(tableCompanies, idCompany, companyName, emailAddressCompany, dateLicenseValidCompany);
        } else {
            errorOccured = true;
            new ErrorAndExceptionHandler().showWarningAlert("License was not choosed");
        }

        if (!errorOccured)
            reinitializeTextFields();
    }

    public void reinitializeTextFields() {
        txtCompanyName.setText("");
        txtFirstName.setText("");
        txtLastName.setText("");
        txtEmailAdress.setText("");
    }

    public void launchEditClient() {
        //new ImplementationTable().editClient(tableIndividuals);
    }

    public void launchDeleteClient() {
        List<Integer> items = new ArrayList<>();

        for (int i = 0; i < tableIndividuals.getSelectionModel().getSelectedItems().size(); i++) {
            items.add(tableIndividuals.getSelectionModel().getSelectedItems().get(i).getId());
        }

        if (tableIndividuals.getSelectionModel().getSelectedItem() == null) {
            new Alert(Alert.AlertType.WARNING, "No cell was selected for this action.", ButtonType.OK).showAndWait();
            return;
        }

        Alert deleteAlert = new Alert(Alert.AlertType.CONFIRMATION, "Delete selected item(s) ?", ButtonType.YES, ButtonType.NO);
        Optional<ButtonType> answer = deleteAlert.showAndWait();

        if (answer.isPresent() && answer.get() == ButtonType.YES) {
            //new ImplementationTable().deleteClient(items);
            //new ImplementationTable().refreshData(tableIndividuals);
            new DataFactory().populateDataInd(tableIndividuals, id, firstName, lastName, emailAdress, dateLicenseValid);
        } else {
            return;
        }
    }

    public void blockExportMenu() {
        if (tableIndividuals.getItems().size() == 0) {
            subMenuExportCsv.setDisable(true);
            subMenuExportJson.setDisable(true);
        } else {
            subMenuExportJson.setDisable(false);
            subMenuExportCsv.setDisable(false);
        }
    }

    public void launchRefreshTable() {
        try {
            DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
            Calendar calendar = Calendar.getInstance();

            //new ImplementationTable().refreshData(tableIndividuals);
            //new ImplementationTable().populateData(tableIndividuals, id, firstName, lastName, emailAdress, dateLicenseValid);
            lblRefreshed.setVisible(true);
            lblRefreshedTime.setText(dateFormat.format(calendar.getTime()));
            lblRefreshedTime.setVisible(true);
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not refresh the table...", e.getMessage());
        }
    }

    public void selectMultipleRows(KeyEvent event) {
        if (event.getCode() == KeyCode.CONTROL)
            tableIndividuals.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    public void handleTabMenuEnabling() {
        if (multipleSelection() <= 1) {
            sepMenuExport.setVisible(false);
            mnTabExportToJson.setVisible(false);
            mnTabExportToCsv.setVisible(false);
        } else {
            sepMenuExport.setVisible(true);
            mnTabExportToJson.setVisible(true);
            mnTabExportToCsv.setVisible(true);
        }
    }

    public int multipleSelection() {
        return (tableIndividuals.getSelectionModel().getSelectedItems().size());
    }

    public void deblockEditMenuItems() {
        try {
            if (tableIndividuals.getSelectionModel().getSelectedItem() != null) {
                mnEditCell.setDisable(false);
                mnDeleteCell.setDisable(false);
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not deblock some menu items...", e.getMessage());
        }
    }

    public void launchEditCell() {
        launchEditClient();
    }

    public void launchDeleteCell() {
        launchDeleteClient();
    }

    public void searchOnEnterPressed(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER)
            searchClient();
    }

    public void launchExportToCsv() {
        List<Integer> items = new ArrayList<>();
        items = getSelectedRows();
        //new ImplementationCsv().exportToCsv(tableIndividuals, items);
    }

    public void copyEmailAdress() {
        String emailAdress = tableIndividuals.getSelectionModel().getSelectedItem().getEmailAdress();
        StringSelection stringSelection = new StringSelection(emailAdress);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
    }

    public void setMenuOnShown() {
        List<MenuItem> menuItems = new ArrayList<>();
        menuItems.add(mnTabCopy);
        menuItems.add(mnTabEdit);
        menuItems.add(mnTabDelete);
        menuItems.add(mnEditCell);
        menuItems.add(mnDeleteCell);

        if (tableIndividuals.getSelectionModel().getSelectedItem() == null) {
            for (int i = 0; i < menuItems.size(); i++) {
                menuItems.get(i).setDisable(true);
            }
        } else if (tableIndividuals.getSelectionModel().getSelectedItems().size() > 1) {
            mnTabCopy.setDisable(true);
            mnTabEdit.setDisable(true);
            mnEditCell.setDisable(true);
        } else {
            for (int i = 0; i < menuItems.size(); i++) {
                menuItems.get(i).setDisable(false);
            }
        }
    }

    public boolean fieldsAreEmpty() {
        List<TextField> fields = new ArrayList<>();
        fields.add(txtEmailAdress);
        fields.add(txtLastName);
        fields.add(txtFirstName);
        fields.add(txtCompanyName);

        for (int i = 0; i < fields.size(); i++) {
            if (!fields.get(i).getText().equals(""))
                return false;
        }
        return true;
    }

    public void exitProgram() {
        if (!fieldsAreEmpty()) {
            Alert deleteAlert = new Alert(Alert.AlertType.CONFIRMATION, "There is unsaved information in the form.\n" +
                    "Close the program anyway?", ButtonType.YES, ButtonType.NO);
            Optional<ButtonType> answer = deleteAlert.showAndWait();

            if (answer.isPresent() && answer.get() == ButtonType.YES)
                System.exit(0);
        } else {
            System.exit(0);
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            txtCompanyName.setEditable(false);
            txtCompanyName.setStyle(BACKGROUND_COLOR_LOCKED);
            mnEditCell.setDisable(true);
            mnDeleteCell.setDisable(true);
            setCurrentDate();

            new ImplementationTable().createTable();
            new DataFactory().populateDataInd(tableIndividuals, id, firstName, lastName, emailAdress, dateLicenseValid);
            new ImplementationTableCompany().createTable();
            new ImplementationTableCompany().populateData(tableCompanies, idCompany, companyName, emailAddressCompany, dateLicenseValidCompany);
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Failed to initialize some objects/methods.", e.getMessage());
        }
    }
}
