package sample;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.core.comp.CompaniesTableModel;
import sample.core.handlers.ErrorAndExceptionHandler;
import sample.core.indv.ModelTable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataFactory {

    private ObservableList<ModelTable> listIndviduals = FXCollections.observableArrayList();
    private ObservableList<CompaniesTableModel> listCompanies = FXCollections.observableArrayList();

    private static final String CONNECTION_URL_IND = "jdbc:sqlite:clients_individuals.db";
    private static final String CONNECTION_URL_COMP = "jdbc:sqlite:clients_companies.db";

    public void populateDataInd(TableView<ModelTable> table, TableColumn<ModelTable, Integer> id, TableColumn<ModelTable, String> firstName,
                                TableColumn<ModelTable, String> lastName, TableColumn<ModelTable, String> emailAdress,
                                TableColumn<ModelTable, String> dateLicenseValid) {
        Platform.runLater(() -> {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL_IND);
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("Select * from content_individuals")) {

                while (resultSet.next()) {
                    table.setPlaceholder(new ProgressBar());
                    listIndviduals.add(new ModelTable(resultSet.getInt("id"), resultSet.getString("FirstName"),
                            resultSet.getString("LastName"), resultSet.getString("EmailAdress"),
                            resultSet.getString("LicenseValidFrom")));
                }

                if (!resultSet.next())
                    table.setPlaceholder(new Label("No results found..."));

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not populate data in the table...", e.getMessage());
            }

            try {
                id.setCellValueFactory(new PropertyValueFactory<>("id"));
                firstName.setCellValueFactory(new PropertyValueFactory<>("FirstName"));
                lastName.setCellValueFactory(new PropertyValueFactory<>("LastName"));
                emailAdress.setCellValueFactory(new PropertyValueFactory<>("EmailAdress"));
                dateLicenseValid.setCellValueFactory(new PropertyValueFactory<>("dateLicenseValid"));
            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not set cellValueFactory for columns...", e.getMessage());
            }
            table.setItems(listIndviduals);

            if (table.getItems().size() == 0)
                table.setPlaceholder(new Label("Table is empty..."));
        });
    }

    public void populateDataComp(TableView<CompaniesTableModel> table, TableColumn<CompaniesTableModel, Integer> id,
                                 TableColumn<CompaniesTableModel, String> companyName,
                                 TableColumn<CompaniesTableModel, String> emailAddress,
                                 TableColumn<CompaniesTableModel, String> dateLicenseValid) {
        Platform.runLater(() -> {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL_COMP);
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("Select * from content_companies")) {

                while (resultSet.next()) {
                    table.setPlaceholder(new ProgressBar());
                    listCompanies.add(new CompaniesTableModel(resultSet.getInt("id"), resultSet.getString("CompanyName"),
                            resultSet.getString("EmailAddress"),
                            resultSet.getString("LicenseValidFrom")));
                }

                if (!resultSet.next())
                    table.setPlaceholder(new Label("No results found..."));

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not populate data in the table...", e.getMessage());
            }

            try {
                id.setCellValueFactory(new PropertyValueFactory<>("id"));
                companyName.setCellValueFactory(new PropertyValueFactory<>("CompanyName"));
                emailAddress.setCellValueFactory(new PropertyValueFactory<>("EmailAddress"));
                dateLicenseValid.setCellValueFactory(new PropertyValueFactory<>("dateLicenseValid"));
            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not set cellValueFactory for columns...", e.getMessage());
            }
            table.setItems(listCompanies);

            if (table.getItems().size() == 0)
                table.setPlaceholder(new Label("Table is empty..."));
        });
    }
}
