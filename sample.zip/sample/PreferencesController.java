package sample;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXDialogLayout;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;

import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import sample.core.handlers.ErrorAndExceptionHandler;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Properties;
import java.util.ResourceBundle;

public class PreferencesController implements Initializable {
    @FXML private ComboBox<String> dateRepresentation;
    @FXML private StackPane stackPane;

    private static final String FILE_NAME = "configuration.properties";

    public void initialiseDateBoxes() {
        dateRepresentation.getItems().addAll("MM/dd/yyyy", "MM.dd.yyy", "dd/MM/yyy", "dd.MM.yyyy",
                "MM-dd-yyy", "dd-MM-yyyy");
    }

    public void aboutDate() {
        JFXDialogLayout content = new JFXDialogLayout();
        content.setHeading(new Text("Date Preference"));
        content.setBody(new Text("Defines how the date will be shown in the table.\nPlease note, after changing date preference" +
                "all dates in existing data\nwill be automatically adjusted to the selected one."));
        stackPane.setVisible(true);
        JFXDialog dialog = new JFXDialog(stackPane, content, JFXDialog.DialogTransition.CENTER);
        JFXButton buttonOk = new JFXButton("OK");

        buttonOk.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                dialog.close();
                stackPane.setVisible(false);
            }
        });
        content.setActions(buttonOk);
        dialog.show();
    }

    public void aboutProgram() {
        JFXDialogLayout content = new JFXDialogLayout();
        content.setHeading(new Text("Do Not Ask Before Closing Program"));
        content.setBody(new Text("The dialog window before closing application will not be\nshown anymore."));
        stackPane.setVisible(true);
        JFXDialog dialog = new JFXDialog(stackPane, content, JFXDialog.DialogTransition.CENTER);
        JFXButton buttonOk = new JFXButton("OK");

        buttonOk.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                dialog.close();
                stackPane.setVisible(false);
            }
        });
        content.setActions(buttonOk);
        dialog.show();
    }

    public void discard() {
        Stage stage = (Stage) dateRepresentation.getScene().getWindow();
        stage.close();
    }

    private void applyPropertiesOnLoad() {
        try (FileInputStream fileInputStream = new FileInputStream(FILE_NAME)) {
            Properties properties = new Properties();
            properties.load(fileInputStream);

            String datePreferenceIndex = properties.getProperty("datePreferenceIndex");
            dateRepresentation.getSelectionModel().select(Integer.valueOf(datePreferenceIndex));

        } catch (Exception e) {
            e.printStackTrace();
            new ErrorAndExceptionHandler().showErrorAlert("Could not apply properties on load...", e.toString());
        }
    }

    public void validate() {
        try (FileOutputStream fileOutputStream = new FileOutputStream(FILE_NAME)) {
            Properties properties = new Properties();

            properties.setProperty("datePreferenceIndex", String.valueOf(dateRepresentation.getSelectionModel().getSelectedIndex()));
            properties.setProperty("datePreferenceString", dateRepresentation.getSelectionModel().getSelectedItem().toString());
            properties.store(fileOutputStream, null);

        } catch (Exception e) {
            e.printStackTrace();
            new ErrorAndExceptionHandler().showErrorAlert("Could not set properties...", e.toString());
        }
        new Alert(Alert.AlertType.INFORMATION, "Changes has been successfully applied.", ButtonType.OK).showAndWait();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initialiseDateBoxes();
        applyPropertiesOnLoad();
    }
}
