package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;
import sample.core.comp.CompaniesTableModel;
import sample.core.handlers.ErrorAndExceptionHandler;
import sample.core.indv.ModelTable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SearchFactory {
    private static final String CONNECTION_URL_IND = "jdbc:sqlite:clients_individuals.db";
    private static final String CONNECTION_URL_COMP = "jdbc:sqlite:clients_companies.db";

    private ObservableList<ModelTable> individualsList = FXCollections.observableArrayList();
    private ObservableList<CompaniesTableModel> companiesList = FXCollections.observableArrayList();

    public void refreshData(TableView<?> table) { table.getItems().clear(); }

    public void searchClient(TableView<ModelTable> tableInd, TableView<CompaniesTableModel> tableComp, String dataToSearch, int tabIndex) {
        if (tabIndex == 0)
            searchIndividual(tableInd, dataToSearch);
        else
            searchCompany(tableComp, dataToSearch);
    }

    public void searchIndividual(TableView<ModelTable> table, String dataToSearch) {
        refreshData(table);

        try (Connection connection = DriverManager.getConnection(CONNECTION_URL_IND);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("select * from content_individuals where firstName like '%" + dataToSearch + "%'")) {

            while (resultSet.next()) {
                individualsList.add(new ModelTable(resultSet.getInt("id"), resultSet.getString("FirstName"),
                        resultSet.getString("LastName"), resultSet.getString("EmailAdress"),
                        resultSet.getString("LicenseValidFrom")));
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not execute research correctly...", e.getMessage());
        }
        table.setItems(individualsList);
    }

    public void searchCompany(TableView<CompaniesTableModel> table, String dataToSearch) {
        refreshData(table);

        try (Connection connection = DriverManager.getConnection(CONNECTION_URL_COMP);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("select * from content_companies where companyName like '%" + dataToSearch + "%'")) {

            while (resultSet.next()) {
                companiesList.add(new CompaniesTableModel(resultSet.getInt("id"), resultSet.getString("CompanyName"),
                        resultSet.getString("EmailAddress"),
                        resultSet.getString("LicenseValidFrom")));
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not execute research correctly...", e.getMessage());
        }
        table.setItems(companiesList);
    }

}
