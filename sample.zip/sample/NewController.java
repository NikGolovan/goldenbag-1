package sample;

import com.jfoenix.controls.JFXTabPane;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import sample.core.comp.CompaniesTableModel;
import sample.core.comp.ImplementationTableCompany;
import sample.core.csv.ImplementationCsv;
import sample.core.handlers.ErrorAndExceptionHandler;
import sample.core.indv.ImplementationTable;
import sample.core.indv.ModelTable;
import sample.core.json.ImplementationJson;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class NewController implements Initializable {

    @FXML private JFXTabPane tabbedPane;
    @FXML private JFXTextField txtSearchIndividual;
    @FXML private JFXTextField txtSearchCompany;

    @FXML private TableColumn<CompaniesTableModel, Integer> idCompany;
    @FXML private TableView<CompaniesTableModel> tableCompanies;
    @FXML private TableColumn<CompaniesTableModel, String> companyName;
    @FXML private TableColumn<CompaniesTableModel, String> emailAddressCompany;
    @FXML private TableColumn<CompaniesTableModel, String> dateLicenseValidCompany;

    @FXML private TableView<ModelTable> tableIndividuals;
    @FXML private TableColumn<ModelTable, Integer> idIndividuals;
    @FXML private TableColumn<ModelTable, String> firstName;
    @FXML private TableColumn<ModelTable, String> lastName;
    @FXML private TableColumn<ModelTable, String> emailAdressIndividuals;
    @FXML private TableColumn<ModelTable, String> dateLicenseValidInd;

    @FXML private Label lblRefreshTimeInd;
    @FXML private Label lblRefreshTimeComp;

    private static final String FILE_NAME = "configuration.properties";

    public void openPreferences() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/sample/gui/Preferences.fxml"));
            fxmlLoader.load();

            Parent parent = fxmlLoader.getRoot();
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Goldenbag - Preferences");
            stage.setScene(new Scene(parent));
            stage.setResizable(false);

            stage.show();
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not open Preferences...", e.toString());
        }
    }

    public void createConfigurationFile() {
        File file = null;

        try {
            file = new File(FILE_NAME);

            if (file.exists())
                return;
            else
                setProperties();

        } catch (Exception e) {
            e.printStackTrace();
            new ErrorAndExceptionHandler().showErrorAlert("Could not create configuration file...", e.toString());
        }
    }

    private void setProperties() {
        try (FileOutputStream fileOutputStream = new FileOutputStream(FILE_NAME)) {
            Properties properties = new Properties();

            properties.setProperty("datePreferenceIndex", "0");
            properties.setProperty("datePreferenceString", "MM/dd/yyyy");
            properties.store(fileOutputStream, null);

        } catch (Exception e) {
            e.printStackTrace();
            new ErrorAndExceptionHandler().showErrorAlert("Could not set properties...", e.toString());
        }
    }

    public void newClient() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/sample/gui/newClient10.fxml"));
            fxmlLoader.load();

            Parent parent = fxmlLoader.getRoot();
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Goldenbag - Add New Client");
            stage.setScene(new Scene(parent));
            stage.setResizable(false);

            stage.show();

        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not edit information...", e.toString());
        }
    }

    public void newCompany() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/sample/gui/newCompany10.fxml"));
            fxmlLoader.load();

            Parent parent = fxmlLoader.getRoot();
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Goldenbag - Add New Company");
            stage.setScene(new Scene(parent));
            stage.setResizable(false);

            stage.show();

        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not edit information...", e.toString());
        }
    }

    public void refreshTable() {
        try {
            DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
            Calendar calendar = Calendar.getInstance();

            if (tabbedPane.getSelectionModel().getSelectedIndex() == 0) {
                new SearchFactory().refreshData(tableIndividuals);
                new DataFactory().populateDataInd(tableIndividuals, idIndividuals, firstName, lastName,
                        emailAdressIndividuals, dateLicenseValidInd);
                lblRefreshTimeInd.setText(dateFormat.format(calendar.getTime()));
            } else {
                new SearchFactory().refreshData(tableIndividuals);
                new DataFactory().populateDataComp(tableCompanies, idCompany, companyName, emailAddressCompany, dateLicenseValidCompany);
                lblRefreshTimeComp.setText(dateFormat.format(calendar.getTime()));
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not refresh the table...", e.toString());
        }
    }

    public void searchClient() {
        if (tabbedPane.getSelectionModel().getSelectedIndex() == 0) {
            new SearchFactory().searchClient(tableIndividuals, tableCompanies,
                    txtSearchIndividual.getText().toString(), tabbedPane.getSelectionModel().getSelectedIndex());
        } else {
            new SearchFactory().searchClient(tableIndividuals, tableCompanies,
                    txtSearchCompany.getText().toString(), tabbedPane.getSelectionModel().getSelectedIndex());
        }
    }

    public void editCell() {
        if (isSelectionNull()) {
            new Alert(Alert.AlertType.WARNING, "No cell was selected for this action.", ButtonType.OK).showAndWait();
            return;
        }
        new ImplementationTable().editClient(tableIndividuals, tableCompanies, tabbedPane.getSelectionModel().getSelectedIndex());
    }

    public boolean isSelectionNull() {
        int tabIndex = tabbedPane.getSelectionModel().getSelectedIndex();

        if (tabIndex == 0) {
            if (tableIndividuals.getSelectionModel().getSelectedItem() == null) {
                return true;
            }
        } else {
            if (tableCompanies.getSelectionModel().getSelectedItem() == null) {
                return true;
            }
        }
        return false;
    }

    public void copyEmailAddress() {
        int tabIndex = tabbedPane.getSelectionModel().getSelectedIndex();

        if (tabIndex == 0) {
            String emailAddressInd = tableIndividuals.getSelectionModel().getSelectedItem().getEmailAdress();

            if (tableIndividuals.getSelectionModel().getSelectedItem() != null) {
                StringSelection stringSelection = new StringSelection(emailAddressInd);
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(stringSelection, null);
            }
        } else {
            String emailAddressComp = tableCompanies.getSelectionModel().getSelectedItem().getEmailAddress();

            if (tableCompanies.getSelectionModel().getSelectedItem() != null) {
                StringSelection stringSelection = new StringSelection(emailAddressComp);
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(stringSelection, null);
            }
        }
    }

    public void launchExportToJson() {
        List<Integer> items = new ArrayList<>();
        int tabIndex = tabbedPane.getSelectionModel().getSelectedIndex();

        try {
            FileChooser fileChooser = new FileChooser();
            File file = fileChooser.showSaveDialog(new Stage());

            items = getSelectedRows(tabIndex);

            if (file == null) {
                return;
            } else {
                file = new File(file.getAbsolutePath() + ".json");
                new ImplementationJson().exportToJson(file, items, tabIndex);
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not process the task...", e.toString());
        }
    }

    public void launchImportJson() {
        try {
            FileChooser fileChooser = new FileChooser();
            FileChooser.ExtensionFilter extensionFilter = new FileChooser.ExtensionFilter("Files *.json", "*.json");
            File file = fileChooser.showOpenDialog(new Stage());

            fileChooser.getExtensionFilters().add(extensionFilter);

            if (file == null) {
                return;
            } else {
                new ImplementationJson().importJson(file, tabbedPane.getSelectionModel().getSelectedIndex());
                if (tabbedPane.getSelectionModel().getSelectedIndex() == 0) {
                    new SearchFactory().refreshData(tableIndividuals);
                    new DataFactory().populateDataInd(tableIndividuals, idIndividuals, firstName, lastName, emailAdressIndividuals, dateLicenseValidInd);
                } else {
                    new SearchFactory().refreshData(tableCompanies);
                    new DataFactory().populateDataComp(tableCompanies, idCompany, companyName, emailAddressCompany, dateLicenseValidCompany);
                }
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Failed to choose a file...", e.toString());
        }
    }

    public List<Integer> getSelectedRows(int tabIndex) {
        if (tabIndex == 0) {
            List<Integer> items = new ArrayList<>();
            for (int i = 0; i < tableIndividuals.getSelectionModel().getSelectedItems().size(); i++) {
                items.add(tableIndividuals.getSelectionModel().getSelectedItems().get(i).getId());
            }
            return (items);
        } else {
            List<Integer> items = new ArrayList<>();
            for (int i = 0; i < tableCompanies.getSelectionModel().getSelectedItems().size(); i++) {
                items.add(tableCompanies.getSelectionModel().getSelectedItems().get(i).getId());
            }
            return (items);
        }
    }

    public void launchExportToCsv() {
        List<Integer> items = new ArrayList<>();
        items = getSelectedRows(tabbedPane.getSelectionModel().getSelectedIndex());

        if (tabbedPane.getSelectionModel().getSelectedIndex() == 0)
            new ImplementationCsv().exportIndividuals(tableIndividuals, items);
        else
            new ImplementationCsv().exportCompanies(tableCompanies, items);
    }

    public void multiRowSelection(KeyEvent event) {
        if (event.getCode() == KeyCode.CONTROL) {
            tableIndividuals.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
            tableCompanies.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        }
    }

    public void launchDeleteClient() {
        List<Integer> items = new ArrayList<>();
        int tabIndex = tabbedPane.getSelectionModel().getSelectedIndex();

        if (tabIndex == 0) {
            for (int i = 0; i < tableIndividuals.getSelectionModel().getSelectedItems().size(); i++) {
                items.add(tableIndividuals.getSelectionModel().getSelectedItems().get(i).getId());
            }
        } else {
            for (int i = 0; i < tableCompanies.getSelectionModel().getSelectedItems().size(); i++) {
                items.add(tableCompanies.getSelectionModel().getSelectedItems().get(i).getId());
            }
        }

        if (tabIndex == 0) {
            if (tableIndividuals.getSelectionModel().getSelectedItem() == null) {
                new Alert(Alert.AlertType.WARNING, "No cell was selected for this action.", ButtonType.OK).showAndWait();
                return;
            }
        } else {
            if (tableCompanies.getSelectionModel().getSelectedItem() == null) {
                new Alert(Alert.AlertType.WARNING, "No cell was selected for this action.", ButtonType.OK).showAndWait();
                return;
            }
        }

        Alert deleteAlert = new Alert(Alert.AlertType.CONFIRMATION, "Delete selected item(s) ?", ButtonType.YES, ButtonType.NO);
        Optional<ButtonType> answer = deleteAlert.showAndWait();

        if (answer.isPresent() && answer.get() == ButtonType.YES) {
            if (tabIndex == 0) {
                new ImplementationTable().deleteClient(items, "content_individuals", "jdbc:sqlite:clients_individuals.db");
                new SearchFactory().refreshData(tableIndividuals);
                new DataFactory().populateDataInd(tableIndividuals, idIndividuals, firstName, lastName, emailAdressIndividuals, dateLicenseValidInd);
            } else {
                new ImplementationTable().deleteClient(items, "content_companies", "jdbc:sqlite:clients_companies.db");
                new SearchFactory().refreshData(tableCompanies);
                new DataFactory().populateDataComp(tableCompanies, idCompany, companyName, emailAddressCompany, dateLicenseValidCompany);
            }
        } else {
            return;
        }
    }

    public void confirmExit() {
        Alert deleteAlert = new Alert(Alert.AlertType.CONFIRMATION, "Close application?", ButtonType.YES, ButtonType.NO);
        Optional<ButtonType> answer = deleteAlert.showAndWait();

        if (answer.isPresent() && answer.get() == ButtonType.YES)
            System.exit(0);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            createConfigurationFile();
            new ImplementationTable().createTable();
            new DataFactory().populateDataInd(tableIndividuals, idIndividuals, firstName, lastName, emailAdressIndividuals, dateLicenseValidInd);
            new ImplementationTableCompany().createTable();
            new ImplementationTableCompany().populateData(tableCompanies, idCompany, companyName, emailAddressCompany, dateLicenseValidCompany);
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Failed to initialize some objects/methods.", e.toString());
        }
    }
}
