package sample;

import com.jfoenix.controls.JFXTabPane;
import com.jfoenix.controls.JFXTextField;
import javafx.beans.binding.DoubleBinding;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import sample.core.companies.CompaniesTableModel;
import sample.core.companies.ImplementationTableCompany;
import sample.core.csv.ImplementationCsv;
import sample.core.factories.DataFactory;
import sample.core.factories.SearchFactory;
import sample.core.handlers.ErrorAndExceptionHandler;
import sample.core.indviduals.ImplementationTable;
import sample.core.indviduals.ModelTable;
import sample.core.data.InitialiseDatabase;
import sample.core.properties.PropertiesInitializer;
import sample.core.json.ImplementationJson;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class Controller implements Initializable {

    @FXML private JFXTabPane tabbedPane;
    @FXML private JFXTextField txtSearchIndividual;
    @FXML private JFXTextField txtSearchCompany;

    @FXML private TableColumn<CompaniesTableModel, Integer> idCompany;
    @FXML private TableView<CompaniesTableModel> tableCompanies;
    @FXML private TableColumn<CompaniesTableModel, String> companyName;
    @FXML private TableColumn<CompaniesTableModel, String> emailAddressCompany;
    @FXML private TableColumn<CompaniesTableModel, String> dateLicenseValidCompany;

    @FXML private TableView<ModelTable> tableIndividuals;
    @FXML private TableColumn<ModelTable, Integer> idIndividuals;
    @FXML private TableColumn<ModelTable, String> firstName;
    @FXML private TableColumn<ModelTable, String> lastName;
    @FXML private TableColumn<ModelTable, String> emailAdressIndividuals;
    @FXML private TableColumn<ModelTable, String> dateLicenseValidInd;

    @FXML private Label lblRefreshTimeInd;
    @FXML private Label lblRefreshTimeComp;

    private ImplementationTable implementationTable;
    private ImplementationCsv implementationCsv;
    private ErrorAndExceptionHandler exceptionHandler;
    private PropertiesInitializer propertiesInitializer;
    private InitialiseDatabase initializerDatabase;
    private ImplementationTableCompany implmentationTableCompane;
    private SearchFactory searchFactory;
    private DataFactory dataFactory;

    public void openPreferences() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/sample/gui/Preferences.fxml"));
            fxmlLoader.load();

            Parent parent = fxmlLoader.getRoot();
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Goldenbag - Preferences");
            stage.setScene(new Scene(parent));
            stage.setResizable(false);

            stage.show();
        } catch (Exception e) {
            exceptionHandler.showErrorAlert("Could not open Preferences...", e.toString());
        }
    }

    public void newClient() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/sample/gui/NewClient.fxml"));
            fxmlLoader.load();

            Parent parent = fxmlLoader.getRoot();
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Goldenbag - Add New Client");
            stage.setScene(new Scene(parent));
            stage.setResizable(false);

            stage.show();

        } catch (Exception e) {
            exceptionHandler.showErrorAlert("Could not edit information...", e.toString());
        }
    }

    public void newCompany() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/sample/gui/NewCompany.fxml"));
            fxmlLoader.load();

            Parent parent = fxmlLoader.getRoot();
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle("Goldenbag - Add New Company");
            stage.setScene(new Scene(parent));
            stage.setResizable(false);

            stage.show();

        } catch (Exception e) {
            exceptionHandler.showErrorAlert("Could not edit information...", e.toString());
        }
    }

    public void refreshTable() {
        try {
            DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
            Calendar calendar = Calendar.getInstance();

            if (tabbedPane.getSelectionModel().getSelectedIndex() == 0) {
                dataFactory.populateDataInd(tableIndividuals, idIndividuals, firstName, lastName,
                        emailAdressIndividuals, dateLicenseValidInd);
                lblRefreshTimeInd.setText(dateFormat.format(calendar.getTime()));
            } else {
                dataFactory.populateDataComp(tableCompanies, idCompany, companyName, emailAddressCompany, dateLicenseValidCompany);
                lblRefreshTimeComp.setText(dateFormat.format(calendar.getTime()));
            }
        } catch (Exception e) {
            exceptionHandler.showErrorAlert("Could not refresh the table...", e.toString());
        }
    }

    public void searchClient() {
        int tabIndex = tabbedPane.getSelectionModel().getSelectedIndex();
        String searchIndividual = txtSearchIndividual.getText().toString();
        String searchCompany = txtSearchCompany.getText().toString();
        String dataToSearch = tabIndex == 0 ? searchIndividual : searchCompany;

        searchFactory.searchClient(tableIndividuals, tableCompanies, dataToSearch, tabIndex);
    }

    public void doubleClickOnRow() {
        tableIndividuals.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent t) {
                if (t.getClickCount() == 2 && tableIndividuals.getSelectionModel().getSelectedItem() != null) {
                    implementationTable.editClient(tableIndividuals, tableCompanies, tabbedPane.getSelectionModel().getSelectedIndex());
                }
            }
        });
        tableCompanies.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent t) {
                if (t.getClickCount() == 2 && tableCompanies.getSelectionModel().getSelectedItem() != null) {
                    implementationTable.editClient(tableIndividuals, tableCompanies, tabbedPane.getSelectionModel().getSelectedIndex());
                }
            }
        });
    }

    public void editCell() {
        int tabIndex = tabbedPane.getSelectionModel().getSelectedIndex();

        if (rowsAreSelected(tabIndex)) {
            new Alert(Alert.AlertType.WARNING, "No cell was selected for this action.", ButtonType.OK).showAndWait();
            return;
        }
        implementationTable.editClient(tableIndividuals, tableCompanies, tabbedPane.getSelectionModel().getSelectedIndex());
    }

    public void copyEmailAddress() {
        int tabIndex = tabbedPane.getSelectionModel().getSelectedIndex();

        if (tabIndex == 0) {
            if (tableIndividuals.getSelectionModel().getSelectedItem() != null) {
                String emailAddressInd = tableIndividuals.getSelectionModel().getSelectedItem().getEmailAdress();
                StringSelection stringSelection = new StringSelection(emailAddressInd);
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(stringSelection, null);
            } else {
                new Alert(Alert.AlertType.WARNING, "No cell was selected for this action.", ButtonType.OK).showAndWait();
            }
        } else {
            if (tableCompanies.getSelectionModel().getSelectedItem() != null) {
                String emailAddressComp = tableCompanies.getSelectionModel().getSelectedItem().getEmailAddress();
                StringSelection stringSelection = new StringSelection(emailAddressComp);
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(stringSelection, null);
            } else {
                new Alert(Alert.AlertType.WARNING, "No cell was selected for this action.", ButtonType.OK).showAndWait();
            }
        }
    }

    public void launchExportToJson() {
        List<Integer> items = new ArrayList<>();
        int tabIndex = tabbedPane.getSelectionModel().getSelectedIndex();

        if (rowsAreSelected(tabIndex)) {
            new Alert(Alert.AlertType.WARNING, "No cell was selected for this action.", ButtonType.OK).showAndWait();
            return;
        }

        try {
            FileChooser fileChooser = new FileChooser();
            File file = fileChooser.showSaveDialog(new Stage());

            items = getSelectedRows(tabIndex);

            if (file == null) {
                return;
            } else {
                file = new File(file.getAbsolutePath() + ".json");
                new ImplementationJson().exportToJson(file, items, tabIndex);
            }
        } catch (Exception e) {
            exceptionHandler.showErrorAlert("Could not process the task...", e.toString());
        }
    }

    public void launchImportJson() {
        try {
            FileChooser fileChooser = new FileChooser();
            FileChooser.ExtensionFilter extensionFilter = new FileChooser.ExtensionFilter("Files *.json", "*.json");
            File file = fileChooser.showOpenDialog(new Stage());

            fileChooser.getExtensionFilters().add(extensionFilter);

            if (file == null) {
                return;
            } else {
                new ImplementationJson().importJson(file, tabbedPane.getSelectionModel().getSelectedIndex());
                if (tabbedPane.getSelectionModel().getSelectedIndex() == 0) {
                    searchFactory.refreshData(tableIndividuals);
                    dataFactory.populateDataInd(tableIndividuals, idIndividuals, firstName, lastName, emailAdressIndividuals, dateLicenseValidInd);
                } else {
                    searchFactory.refreshData(tableCompanies);
                    dataFactory.populateDataComp(tableCompanies, idCompany, companyName, emailAddressCompany, dateLicenseValidCompany);
                }
            }
        } catch (Exception e) {
            exceptionHandler.showErrorAlert("Failed to choose a file...", e.toString());
        }
    }

    public List<Integer> getSelectedRows(int tabIndex) {
        List<Integer> items = new ArrayList<>();

        if (tabIndex == 0) {
            for (int i = 0; i < tableIndividuals.getSelectionModel().getSelectedItems().size(); i++) {
                items.add(tableIndividuals.getSelectionModel().getSelectedItems().get(i).getId());
            }
        } else {
            for (int i = 0; i < tableCompanies.getSelectionModel().getSelectedItems().size(); i++) {
                items.add(tableCompanies.getSelectionModel().getSelectedItems().get(i).getId());
            }
        }
        return items;
    }

    public void launchExportToCsv() {
        List<Integer> items = new ArrayList<>();
        items = getSelectedRows(tabbedPane.getSelectionModel().getSelectedIndex());
        int tabIndex = tabbedPane.getSelectionModel().getSelectedIndex();

        if (rowsAreSelected(tabIndex)) {
            new Alert(Alert.AlertType.WARNING, "No cell was selected for this action.", ButtonType.OK).showAndWait();
            return;
        }

        if (tabbedPane.getSelectionModel().getSelectedIndex() == 0)
            implementationCsv.exportIndividuals(tableIndividuals, items);
        else
            implementationCsv.exportCompanies(tableCompanies, items);
    }

    public void multiRowSelection(KeyEvent event) {
        if (event.getCode() == KeyCode.CONTROL) {
            tableIndividuals.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
            tableCompanies.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        }
    }

    public boolean rowsAreSelected(int tabIndex) {
        if (tabIndex == 0)
            return (tableIndividuals.getSelectionModel().getSelectedItem() == null);
         else
            return (tableCompanies.getSelectionModel().getSelectedItem() == null);
    }

    public void launchDeleteClient() {
        List<Integer> items = new ArrayList<>();
        int tabIndex = tabbedPane.getSelectionModel().getSelectedIndex();

        items = getSelectedRows(tabIndex);

        if (rowsAreSelected(tabIndex)) {
            new Alert(Alert.AlertType.WARNING, "No cell was selected for this action.", ButtonType.OK).showAndWait();
            return;
        }

        Alert deleteAlert = new Alert(Alert.AlertType.CONFIRMATION, "Delete selected item(s) ?", ButtonType.YES, ButtonType.NO);
        Optional<ButtonType> answer = deleteAlert.showAndWait();

        if (answer.isPresent() && answer.get() == ButtonType.YES) {
            if (tabIndex == 0) {
                implementationTable.deleteClient(items, "content_individuals", "jdbc:sqlite:clients_individuals.db");
                searchFactory.refreshData(tableIndividuals);
                dataFactory.populateDataInd(tableIndividuals, idIndividuals, firstName, lastName, emailAdressIndividuals, dateLicenseValidInd);
            } else {
                implementationTable.deleteClient(items, "content_companies", "jdbc:sqlite:clients_companies.db");
                searchFactory.refreshData(tableCompanies);
                dataFactory.populateDataComp(tableCompanies, idCompany, companyName, emailAddressCompany, dateLicenseValidCompany);
            }
        } else {
            return;
        }
    }

    public void confirmExit() {
        Alert deleteAlert = new Alert(Alert.AlertType.CONFIRMATION, "Close application?", ButtonType.YES, ButtonType.NO);
        Optional<ButtonType> answer = deleteAlert.showAndWait();

        if (answer.isPresent() && answer.get() == ButtonType.YES)
            System.exit(0);
    }

    public void aboutGoldenbag() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("ABOUT GOLDENBAG");
        alert.setHeaderText("ABOUT");
        alert.setContentText("Goldenbag is an application that helps to track payments for\nthe licenses that you distribute for you product.");

        alert.showAndWait();
    }

    public void setTableResizePolicy() {
        tableIndividuals.setColumnResizePolicy(tableIndividuals.CONSTRAINED_RESIZE_POLICY);
        tableCompanies.setColumnResizePolicy(tableIndividuals.CONSTRAINED_RESIZE_POLICY);
    }

    public void adjustTabs() {
        tabbedPane.widthProperty().addListener((observable, oldValue, newValue) -> {
            tabbedPane.setTabMinWidth(tabbedPane.getWidth() / 2);
            tabbedPane.setTabMaxWidth(tabbedPane.getWidth() / 2);
        });
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            implementationTable = new ImplementationTable();
            implementationCsv = new ImplementationCsv();
            exceptionHandler = new ErrorAndExceptionHandler();
            propertiesInitializer = new PropertiesInitializer();
            initializerDatabase = new InitialiseDatabase();
            implmentationTableCompane = new ImplementationTableCompany();
            searchFactory = new SearchFactory();
            dataFactory = new DataFactory();
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Failed to create an instance of a class on loading...", e.toString());
        }

        setTableResizePolicy();
        adjustTabs();

        try {
            propertiesInitializer.createConfigurationFile();
            initializerDatabase.createTableIndividuals();
            dataFactory.populateDataInd(tableIndividuals, idIndividuals, firstName, lastName, emailAdressIndividuals, dateLicenseValidInd);
            initializerDatabase.createTableICompanies();
            implmentationTableCompane.populateData(tableCompanies, idCompany, companyName, emailAddressCompany, dateLicenseValidCompany);
        } catch (Exception e) {
            exceptionHandler.showErrorAlert("Failed to initialize some objects/methods.", e.toString());
        }
    }
}
