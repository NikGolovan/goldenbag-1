package sample.core.edit;

import com.jfoenix.controls.JFXDatePicker;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import sample.core.factories.DateFactory;
import sample.core.handlers.ErrorAndExceptionHandler;
import sample.core.properties.PropertiesMethods;

import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class EditClientController extends PropertiesMethods implements Initializable, DateFactory {

    @FXML public TextField txtId;
    @FXML public TextField txtFirstname;
    @FXML public TextField txtLastname;
    @FXML public TextField txtCompanyName;
    @FXML public TextField txtEmailAddress;
    @FXML public JFXDatePicker dateField;
    @FXML public Button btnDiscard;
    @FXML public Button btnConfirm;

    private int tabIndex = 0;
    private static final String CONNECTION_URL_IND = "jdbc:sqlite:clients_individuals.db";
    private static final String CONNECTION_URL_COMP = "jdbc:sqlite:clients_companies.db";

    public void setFields(int id, String firstName, String lastName, String companyName, String emailAddress, String datePayment, int tabIndex) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(getPropertyFromFile("datePreferenceString"));

        this.txtId.setText(String.valueOf(id));
        this.txtFirstname.setText(firstName);
        this.txtLastname.setText(lastName);
        this.txtCompanyName.setText(companyName);
        this.txtEmailAddress.setText(emailAddress);
        this.dateField.setValue(LocalDate.parse(datePayment, formatter));
        this.tabIndex = tabIndex;
        blockSomeFields();
    }

    public void blockSomeFields() {
        if (tabIndex == 0) {
            txtId.setDisable(true);
            txtCompanyName.setDisable(true);
        } else {
            txtId.setDisable(true);
            txtFirstname.setDisable(true);
            txtLastname.setDisable(true);
        }
    }

    public void discard() {
        Stage stage = (Stage) btnDiscard.getScene().getWindow();
        stage.close();
    }

    // returns a list of ancient dates that should be changed to new date format
    @Override
    public List<String> getOldDateFormat(String connectionUrl, String tableName) {
        List<String> dates = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(connectionUrl);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("select LicenseValidFrom from " + tableName)) {

            while (resultSet.next()) {
                dates.add(resultSet.getString(1));
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not get dates from a table to change the format...", e.getMessage());
        }
        return dates;
    }

    @Override
    public List<String> dateParser(List<String> dates) {
        List<String> results = new ArrayList<>();
        StringBuilder newDate = null;
        char regex = 0;

        switch (getPropertyFromFile("datePreferenceString")) {
            case "dd/MM/yyyy":
                regex = '/';
                break;
            case "dd.MM.yyyy":
                regex = '.';
                break;
            case "dd-MM-yyyy":
                regex = '-';
                break;
        }

        for (int i = 0; i < dates.size(); i++) {
            newDate = new StringBuilder(dates.get(i));
            newDate.setCharAt(2, regex);
            newDate.setCharAt(5, regex);
            results.add(newDate.toString());
        }
        return results;
    }

    // prevents to convert date format to yyyy-MM-dd when changes has been applied in edit window
    @Override
    public String getCorrectDateFormat(DatePicker datePicker) {
        DateTimeFormatter OLD_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter NEW_FORMATTER = DateTimeFormatter.ofPattern(getPropertyFromFile("datePreferenceString"));
        String newString = null;

        String oldString = datePicker.getValue().toString();
        LocalDate date = LocalDate.parse(oldString, OLD_FORMATTER);
        newString = date.format(NEW_FORMATTER);

        return newString;
    }

    public void updateSqlDateformat() {
        List<String> datesIndividuals = getOldDateFormat(CONNECTION_URL_IND, "content_individuals");
        List<String> datesCompanies = getOldDateFormat(CONNECTION_URL_COMP, "content_companies");
        List<String> parsedDatesInd = new ArrayList<>();
        List<String> parsedDateComp = new ArrayList<>();
        parsedDatesInd = dateParser(datesIndividuals);
        parsedDateComp = dateParser(datesCompanies);

        try (Connection connection = DriverManager.getConnection(CONNECTION_URL_IND);
             PreparedStatement preparedStatement = connection.prepareStatement("update content_individuals set LicenseValidFrom = ?")) {

            for (int i = 0; i < parsedDatesInd.size(); i++) {
                preparedStatement.setString(1, parsedDatesInd.get(i));
                preparedStatement.executeUpdate();
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not set new SQL date format...", e.getMessage());
        }

        try (Connection connection = DriverManager.getConnection(CONNECTION_URL_COMP);
             PreparedStatement preparedStatement = connection.prepareStatement("update content_companies set LicenseValidFrom = ?")) {

            for (int i = 0; i < parsedDateComp.size(); i++) {
                preparedStatement.setString(1, parsedDateComp.get(i));
                preparedStatement.executeUpdate();
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not set new SQL date format...", e.getMessage());
        }
    }

    public void saveChanges() {
        if (tabIndex != 0) {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL_COMP);
                 PreparedStatement preparedStatement = connection.prepareStatement("update content_companies set companyName = ?," +
                         " emailAddress = ?, LicenseValidFrom = ? where id = " + txtId.getText())) {

                preparedStatement.setString(1, txtCompanyName.getText());
                preparedStatement.setString(2, txtEmailAddress.getText());
                preparedStatement.setString(3, getCorrectDateFormat(dateField));

                preparedStatement.executeUpdate();

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not save information...", e.getMessage());
            }
            new Alert(Alert.AlertType.INFORMATION, "The information was successfully updated.", ButtonType.OK).showAndWait();
        } else {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL_IND);
                 PreparedStatement preparedStatement = connection.prepareStatement("update content_individuals set firstName = ?," +
                         " lastName = ?, emailAdress = ?, LicenseValidFrom = ? where id = " + txtId.getText())) {

                preparedStatement.setString(1, txtFirstname.getText());
                preparedStatement.setString(2, txtLastname.getText());
                preparedStatement.setString(3, txtEmailAddress.getText());
                preparedStatement.setString(4, getCorrectDateFormat(dateField));

                preparedStatement.executeUpdate();

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not save information...", e.getMessage());
            }
            new Alert(Alert.AlertType.INFORMATION, "The information was successfully updated.", ButtonType.OK).showAndWait();
        }
    }

    public void setCurrentDate() {
        try {
            dateField.setValue(LocalDate.now());
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Oops, an error has occurred. Details:\n" + e.getMessage(), ButtonType.OK);
        }
    }

    @Override
    public void initialize (URL location, ResourceBundle resources) { }
}
