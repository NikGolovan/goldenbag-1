package sample.core.preferences;

import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import sample.Controller;
import sample.core.edit.EditClientController;
import sample.core.factories.DataFactory;
import sample.core.factories.SearchFactory;
import sample.core.handlers.ErrorAndExceptionHandler;
import sample.core.properties.PropertiesMethods;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.Optional;
import java.util.Properties;
import java.util.ResourceBundle;

public class PreferencesController extends PropertiesMethods implements Initializable {
    @FXML private ComboBox<String> dateRepresentation;
    @FXML private CheckBox askBeforeClosing;
    @FXML private StackPane stackPaneGeneral;
    @FXML private StackPane stackPaneImportExport;
    @FXML private StackPane stackPaneData;
    @FXML private JFXTextField txtJsonDatasetName;
    @FXML private CheckBox checkAllowEmptyUploading;

    ErrorAndExceptionHandler exceptionHandler;
    EditClientController editClientController;

    private static final String FILE_NAME = "configuration.properties";

    public void initialiseDateBoxes() {
        dateRepresentation.getItems().addAll("dd/MM/yyyy", "dd.MM.yyyy", "dd-MM-yyyy");
    }

    public void focusAll() {
        txtJsonDatasetName.selectAll();
    }

    public void aboutDate() {
        new QuestionMarkMessages().showAboutDate(stackPaneGeneral);
    }

    public void aboutJsonDataset() {
        new QuestionMarkMessages().showAboutDatasetJson(stackPaneImportExport);
    }

    public void aboutUploadingForms() {
        new QuestionMarkMessages().showAboutUploadingForms(stackPaneData);
    }

    public void aboutProgram() {
        new QuestionMarkMessages().showAboutProgram(stackPaneGeneral);
    }

    public void discard() {
        Stage stage = (Stage) dateRepresentation.getScene().getWindow();
        stage.close();
    }

    private void applyPropertiesOnLoad() {
        try {
            dateRepresentation.getSelectionModel().select(Integer.valueOf(getPropertyFromFile("datePreferenceIndex")));
            askBeforeClosing.setSelected(Boolean.valueOf(getPropertyFromFile("closeDialogWindow")));
            checkAllowEmptyUploading.setSelected(Boolean.valueOf("allowUploadIncompleteForm"));
            txtJsonDatasetName.setText(getPropertyFromFile("jsonDatasetName"));
        } catch (Exception e) {
            exceptionHandler.showErrorAlert("Could not apply properties on load...", e.toString());
        }
    }

    public void validate() {
        try (FileOutputStream fileOutputStream = new FileOutputStream(FILE_NAME)) {
            Properties properties = new Properties();

            properties.setProperty("datePreferenceIndex", String.valueOf(dateRepresentation.getSelectionModel().getSelectedIndex()));
            properties.setProperty("datePreferenceString",dateRepresentation.getSelectionModel().getSelectedItem().toString());
            properties.setProperty("closeDialogWindow",   String.valueOf(askBeforeClosing.isSelected()));
            properties.setProperty("allowUploadIncompleteForm", String.valueOf(checkAllowEmptyUploading.isSelected()));
            properties.setProperty("jsonDatasetName", txtJsonDatasetName.getText());
            properties.store(fileOutputStream, null);

            new EditClientController().updateSqlDateformat();
        } catch (Exception e) {
            e.printStackTrace();
            new ErrorAndExceptionHandler().showErrorAlert("Could not set properties...", e.toString());
        }
        new Alert(Alert.AlertType.INFORMATION, "Changes has been successfully applied.", ButtonType.OK).showAndWait();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            exceptionHandler = new ErrorAndExceptionHandler();
            editClientController = new EditClientController();
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not initialize some instances...", e.toString());
        }
        initialiseDateBoxes();
        applyPropertiesOnLoad();
    }

    public void setToDefault() {
        Alert deleteAlert = new Alert(Alert.AlertType.CONFIRMATION, "Set all configurations by default?", ButtonType.YES, ButtonType.NO);
        Optional<ButtonType> answer = deleteAlert.showAndWait();

        if (answer.isPresent() && answer.get() == ButtonType.YES) {
            dateRepresentation.getSelectionModel().select(0);
            askBeforeClosing.setSelected(false);
            txtJsonDatasetName.setText("records");
            checkAllowEmptyUploading.setSelected(false);

            validate();
        } else {
            return;
        }
    }
}
