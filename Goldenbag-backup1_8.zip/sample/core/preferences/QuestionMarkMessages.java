package sample.core.preferences;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXDialogLayout;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;

public class QuestionMarkMessages {
    public void showAboutDate(StackPane stackPane) {
        JFXDialogLayout content = new JFXDialogLayout();
        content.setHeading(new Text("Date Preference"));
        content.setBody(new Text("Defines how the date will be shown in the table.\nPlease note, after changing date preference" +
                "all dates in existing data\nwill be automatically adjusted to the selected one."));
        stackPane.setVisible(true);
        JFXDialog dialog = new JFXDialog(stackPane, content, JFXDialog.DialogTransition.CENTER);
        JFXButton buttonOk = new JFXButton("OK");

        buttonOk.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                dialog.close();
                stackPane.setVisible(false);
            }
        });
        content.setActions(buttonOk);
        dialog.show();
    }

    public void showAboutDatasetJson(StackPane stackPane) {
        JFXDialogLayout content = new JFXDialogLayout();
        content.setHeading(new Text("JSON Data Set"));
        content.setBody(new Text("The name under which your dataset is stored and imported to the program\nPlease note, if DataSet name is different" +
                " the import could not be performed.\n"));
        stackPane.setVisible(true);
        JFXDialog dialog = new JFXDialog(stackPane, content, JFXDialog.DialogTransition.CENTER);
        JFXButton buttonOk = new JFXButton("OK");

        buttonOk.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                dialog.close();
                stackPane.setVisible(false);
            }
        });
        content.setActions(buttonOk);
        dialog.show();
    }

    public void showAboutProgram(StackPane stackPane) {
        JFXDialogLayout content = new JFXDialogLayout();
        content.setHeading(new Text("Do Not Ask Before Closing Program"));
        content.setBody(new Text("The dialog window before closing application will not be\nshown anymore."));
        stackPane.setVisible(true);
        JFXDialog dialog = new JFXDialog(stackPane, content, JFXDialog.DialogTransition.CENTER);
        JFXButton buttonOk = new JFXButton("OK");

        buttonOk.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                dialog.close();
                stackPane.setVisible(false);
            }
        });
        content.setActions(buttonOk);
        dialog.show();
    }


    public void showAboutUploadingForms(StackPane stackPane) {
        JFXDialogLayout content = new JFXDialogLayout();
        content.setHeading(new Text("Allow Uploading Of Incomplete Forms"));
        content.setBody(new Text("By default the program does not allow to leave empty fields in the form\n" +
                "however, this checkbox allows to upload empty fields to the database."));
        stackPane.setVisible(true);
        JFXDialog dialog = new JFXDialog(stackPane, content, JFXDialog.DialogTransition.CENTER);
        JFXButton buttonOk = new JFXButton("OK");

        buttonOk.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                dialog.close();
                stackPane.setVisible(false);
            }
        });
        content.setActions(buttonOk);
        dialog.show();
    }
}
