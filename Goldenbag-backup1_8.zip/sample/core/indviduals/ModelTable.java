package sample.core.indviduals;

public class ModelTable {
    Integer id;
    String firstName, lastName, emailAdress, LicenseValidFrom;

    public ModelTable(Integer id, String firstName, String lastName, String emailAddress, String LicenseValidFrom) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAdress = emailAddress;
        this.LicenseValidFrom = LicenseValidFrom;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmailAdress() {
        return emailAdress;
    }

    public void setEmailAdress(String emailAdress) {
        this.emailAdress = emailAdress;
    }

    public String getDateLicenseValid() {
        return LicenseValidFrom;
    }

    public void setDateLicenseValid(String LicenseValidFrom) {
        this.LicenseValidFrom = LicenseValidFrom;
    }
}
