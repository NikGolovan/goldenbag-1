package sample.core.companies;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import sample.core.handlers.ErrorAndExceptionHandler;
import sample.core.properties.PropertiesMethods;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class NewCompanyController extends PropertiesMethods implements Initializable {
    @FXML private JFXTextField txtCompanyName;
    @FXML private JFXTextField txtEmailAddress;
    @FXML private JFXDatePicker datePickerNewCompany;

    private static final String CONNECTION_URL = "jdbc:sqlite:clients_companies.db";

    public void setCurrentDate() {
        try {
            datePickerNewCompany.setValue(LocalDate.now());
        } catch (Exception e) {
            new Alert(Alert.AlertType.ERROR, "Oops, an error has occurred. Details:\n" + e.getMessage(), ButtonType.OK);
        }
    }

    public void discard() {
        Stage stage = (Stage) datePickerNewCompany.getScene().getWindow();
        stage.close();
    }

    public boolean fieldsAreEmpty(List<String> fields) {
        for (int i = 0; i < fields.size(); i++) {
            if (fields.get(i).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    public void saveInformation() {
        String companyName = txtCompanyName.getText();
        String emailAddress = txtEmailAddress.getText();
        String dateLicenseValid = datePickerNewCompany.getValue().format(DateTimeFormatter.ofPattern(getPropertyFromFile("datePreferenceString")));

        List<String> fields = new ArrayList<>();

        fields.add(emailAddress);
        fields.add(dateLicenseValid);

        if (Boolean.valueOf(getPropertyFromFile("allowUploadIncompleteForm"))) {
            uploadToSqlite(companyName, emailAddress, dateLicenseValid);
        } else {
            if (fieldsAreEmpty(fields)) {
                new ErrorAndExceptionHandler().showWarningAlert("Form is incomplete.");
                return;
            }
            uploadToSqlite(companyName, emailAddress, dateLicenseValid);
        }
        txtCompanyName.setText("");
        txtEmailAddress.setText("");
    }

    public void uploadToSqlite(String companyName, String emailAddress, String datePayment) {
        Platform.runLater(() -> {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL);
                 PreparedStatement preparedStatement = connection.prepareStatement("insert into content_companies values (?, ?, ?, ?)")) {

                preparedStatement.setString(2, companyName);
                preparedStatement.setString(3, emailAddress);
                preparedStatement.setString(4, datePayment);

                preparedStatement.executeUpdate();

            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not upload information to the table...", e.toString());
            }
        });
        new Alert(Alert.AlertType.INFORMATION, "New company has been successfully added to the database.", ButtonType.OK).showAndWait();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setCurrentDate();
    }
}
