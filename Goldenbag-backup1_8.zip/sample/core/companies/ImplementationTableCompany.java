package sample.core.companies;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.core.handlers.ErrorAndExceptionHandler;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ImplementationTableCompany {
    private static final String CONNECTION_URL = "jdbc:sqlite:clients_companies.db";
    private ObservableList<CompaniesTableModel> oblist = FXCollections.observableArrayList();

    public boolean fieldsAreEmpty(List<String> fields) {
        for (int i = 0; i < fields.size(); i++) {
            if (fields.get(i).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    public void refreshData(TableView<CompaniesTableModel> table) { table.getItems().clear(); }

    public void populateData(TableView<CompaniesTableModel> table, TableColumn<CompaniesTableModel, Integer> id,
                             TableColumn<CompaniesTableModel, String> companyName, TableColumn<CompaniesTableModel, String> emailAddress,
                             TableColumn<CompaniesTableModel, String> dateLicenseValid) {
        Platform.runLater(() -> {
            try (Connection connection = DriverManager.getConnection(CONNECTION_URL);
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("Select * from content_companies")) {

                while (resultSet.next()) {
                    oblist.add(new CompaniesTableModel(resultSet.getInt("id"), resultSet.getString("companyName"),
                            resultSet.getString("EmailAddress"),
                            resultSet.getString("LicenseValidFrom")));
                }
            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not populate data in the table...", e.toString());
            }

            try {
                id.setCellValueFactory(new PropertyValueFactory<>("id"));
                companyName.setCellValueFactory(new PropertyValueFactory<>("companyName"));
                emailAddress.setCellValueFactory(new PropertyValueFactory<>("EmailAddress"));
                dateLicenseValid.setCellValueFactory(new PropertyValueFactory<>("dateLicenseValid"));
            } catch (Exception e) {
                new ErrorAndExceptionHandler().showErrorAlert("Could not set cellValueFactory for columns...", e.toString());
                e.printStackTrace();
            }
            table.setItems(oblist);

            if (table.getItems().size() == 0)
                table.setPlaceholder(new Label("Table is empty..."));
        });

    }

    public void uploadToSqlite(String companyName, String emailAdress, String datePayment) {
        try (Connection connection = DriverManager.getConnection(CONNECTION_URL);
             PreparedStatement preparedStatement = connection.prepareStatement("insert into content_companies values (?, ?, ?, ?)")) {

            preparedStatement.setString(2, companyName);
            preparedStatement.setString(3, emailAdress);
            preparedStatement.setString(4, datePayment);

            preparedStatement.executeUpdate();

        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not upload information to the table...", e.toString());
        }
    }

    public void saveInformation(String companyName, String emailAdress, String datePayment) {
        List<String> fields = new ArrayList<>();

        fields.add(companyName);
        fields.add(String.valueOf(datePayment));
        fields.add(emailAdress);

        if (fieldsAreEmpty(fields)) {
            new ErrorAndExceptionHandler().showWarningAlert("Form is incomplete.");
            return;
        }
        uploadToSqlite(companyName, emailAdress, datePayment);
    }

    public void deleteClient(List<Integer> items) {
        try (Connection connection = DriverManager.getConnection(CONNECTION_URL);
             Statement statement = connection.createStatement()) {

            for (int i = 0; i < items.size(); i++) {
                statement.execute("delete from content_companies where id like '%" + items.get(i) + "%'");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
