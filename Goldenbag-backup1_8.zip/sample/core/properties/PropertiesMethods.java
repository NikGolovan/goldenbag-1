package sample.core.properties;

import sample.core.handlers.ErrorAndExceptionHandler;

import java.io.FileInputStream;
import java.util.Properties;

public abstract class PropertiesMethods {
    private static final String FILE_NAME = "configuration.properties";

    public String getPropertyFromFile(String propertyName) {
         Properties properties = new Properties();
         String property = null;

         try (FileInputStream fileInputStream = new FileInputStream(FILE_NAME)) {
             properties.load(fileInputStream);

             property = properties.getProperty(propertyName);

         } catch (Exception e) {
             e.printStackTrace();
             new ErrorAndExceptionHandler().showErrorAlert("Could not get property from .properties file...", e.toString());
         }
         return property;
     }
 }
