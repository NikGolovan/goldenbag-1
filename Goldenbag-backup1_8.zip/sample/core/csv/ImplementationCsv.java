package sample.core.csv;

import javafx.scene.control.TableView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import sample.core.companies.CompaniesTableModel;
import sample.core.handlers.ErrorAndExceptionHandler;
import sample.core.indviduals.ModelTable;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.List;

public class ImplementationCsv {

    public void exportIndividuals(TableView<ModelTable> table, List<Integer> items) {
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showSaveDialog(new Stage());

        if (file == null)
            return;
        else
            file = new File(file.getAbsolutePath() + ".csv");

        try (Writer printWriter = new BufferedWriter(new FileWriter(file))) {

            if (items.size() <= 1) {
                for (int i = 0; i < table.getItems().size(); i++) {
                    String text = table.getItems().get(i).getId() + ";" + table.getItems().get(i).getFirstName()
                            + ";" + table.getItems().get(i).getLastName()  + ";" + table.getItems().get(i).getEmailAdress()
                            + ";" + table.getItems().get(i).getDateLicenseValid().replace('.', ',') + "\n";
                    printWriter.write(text);
                }
            } else {
                for (int i = 0; i < items.size(); i++) {
                    String text = table.getSelectionModel().getSelectedItems().get(i).getId() + ";" +
                            table.getSelectionModel().getSelectedItems().get(i).getFirstName()
                            + ";" + table.getSelectionModel().getSelectedItems().get(i).getLastName() + ";" +
                            table.getSelectionModel().getSelectedItems().get(i).getEmailAdress()
                            + ";" + table.getSelectionModel().getSelectedItems().get(i).getDateLicenseValid() + "\n";
                    printWriter.write(text);
                }
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not process the task...", e.getMessage());
        }
        new ErrorAndExceptionHandler().showConfirmationAlert("File was successfully created.");
    }

    public void exportCompanies(TableView<CompaniesTableModel> table, List<Integer> items) {
        FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showSaveDialog(new Stage());

        if (file == null)
            return;
        else
            file = new File(file.getAbsolutePath() + ".csv");

        try (Writer printWriter = new BufferedWriter(new FileWriter(file))) {

            if (items.size() <= 1) {
                for (int i = 0; i < table.getItems().size(); i++) {
                    String text = table.getItems().get(i).getId() + ";" + table.getItems().get(i).getCompanyName()
                            + ";" + table.getItems().get(i).getDateLicenseValid().replace('.', ',') + "\n";
                    printWriter.write(text);
                }
            } else {
                for (int i = 0; i < items.size(); i++) {
                    String text = table.getSelectionModel().getSelectedItems().get(i).getId() + ";" +
                            table.getSelectionModel().getSelectedItems().get(i).getCompanyName()
                            + ";" + table.getSelectionModel().getSelectedItems().get(i).getDateLicenseValid() + "\n";
                    printWriter.write(text);
                }
            }
        } catch (Exception e) {
            new ErrorAndExceptionHandler().showErrorAlert("Could not process the task...", e.getMessage());
        }
        new ErrorAndExceptionHandler().showConfirmationAlert("File was successfully created.");
    }
}
